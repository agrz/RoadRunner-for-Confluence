
java -Xms256m -Xmx256m -jar rr.jar

