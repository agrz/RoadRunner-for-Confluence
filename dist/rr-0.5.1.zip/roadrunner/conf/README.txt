this file and dir are not really needed but the current build structure still expects this directory to exist so this file is a place holder for Git to create the correct dir structure on checkout.
